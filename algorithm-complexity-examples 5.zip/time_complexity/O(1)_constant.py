def get_first_element(arr):
    return arr[0]

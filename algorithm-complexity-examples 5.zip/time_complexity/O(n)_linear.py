def find_element(arr, target):
    for item in arr:
        if item == target:
            return True
    return False
